export const MONTE_CARLO_INBOUND_TOPIC = 'monteCarloInboundTopic';
export const MONTE_CARLO_OUTBOUND_TOPIC = 'monteCarloOutboundTopic';
export const FRESH_DESK_INBOUND_TOPIC = 'freshDeskInboundTopic';
export const FRESH_DESK_OUTBOUND_TOPIC = 'freshDeskOutboundTopic';
export const MONTE_CARLO_INBOUND_QUEUE = 'monteCarloInboundQueue';
export const FRESH_DESK_INBOUND_QUEUE = 'freshDeskInboundQueue';
export const FRESH_DESK_CLIENT_ID = 'freshDeskClientId';
export const MONTE_CARLO_CLIENT_ID = 'monteCarloClientId';
