import { DeploymentEnvironment, DeploymentStack, SoftwareType } from '@amzn/pipelines';
import { Topic } from 'aws-cdk-lib/aws-sns';
import { Queue } from 'aws-cdk-lib/aws-sqs';
import { Construct } from 'constructs';
import { FRESH_DESK_INBOUND_QUEUE, MONTE_CARLO_INBOUND_QUEUE } from './constants';
import { Duration } from 'aws-cdk-lib';
import { SqsSubscription } from 'aws-cdk-lib/aws-sns-subscriptions';

interface SqsStackProps {
  readonly env: DeploymentEnvironment;
  readonly stage: string;
  readonly monteCarloInboundTopic: Topic;
  readonly freshDeskInboundTopic: Topic;
}

export class SqsStack extends DeploymentStack {
  public readonly monteCarloInboundQueue: Queue;
  public readonly freshDeskInboundQueue: Queue;
  public readonly monteCarloInboundDlq: Queue;
  public readonly freshDeskInboundDlq: Queue;

  constructor(scope: Construct, id: string, props: SqsStackProps) {
    super(scope, id, {
      env: props.env,
      softwareType: SoftwareType.INFRASTRUCTURE,
    });

    const monteCarloInboundQueueName = `${MONTE_CARLO_INBOUND_QUEUE}-${props.stage}`;
    this.monteCarloInboundDlq = new Queue(this, `${monteCarloInboundQueueName}-dlq`, {
      queueName: `${monteCarloInboundQueueName}-dlq`,
    });
    this.monteCarloInboundQueue = new Queue(this, monteCarloInboundQueueName, {
      queueName: monteCarloInboundQueueName,
      visibilityTimeout: Duration.minutes(5),
      deadLetterQueue: {
        queue: this.monteCarloInboundDlq,
        maxReceiveCount: 3,
      },
    });

    props.monteCarloInboundTopic.addSubscription(new SqsSubscription(this.monteCarloInboundQueue));

    const freshDeskInboundQueueName = `${FRESH_DESK_INBOUND_QUEUE}-${props.stage}`;
    this.freshDeskInboundDlq = new Queue(this, `${FRESH_DESK_INBOUND_QUEUE}-dlq`, {
      queueName: `${FRESH_DESK_INBOUND_QUEUE}-dlq`,
    });
    this.freshDeskInboundQueue = new Queue(this, freshDeskInboundQueueName, {
      queueName: freshDeskInboundQueueName,
      visibilityTimeout: Duration.minutes(5),
      deadLetterQueue: {
        queue: this.freshDeskInboundDlq,
        maxReceiveCount: 3,
      },
    });

    props.freshDeskInboundTopic.addSubscription(new SqsSubscription(this.freshDeskInboundQueue));
  }
}
