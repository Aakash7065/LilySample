import { DeploymentEnvironment, DeploymentStack, SoftwareType } from '@amzn/pipelines';
import { Construct } from 'constructs';
import { Topic } from 'aws-cdk-lib/aws-sns';
import {
  FRESH_DESK_INBOUND_TOPIC,
  FRESH_DESK_OUTBOUND_TOPIC,
  MONTE_CARLO_INBOUND_TOPIC,
  MONTE_CARLO_OUTBOUND_TOPIC,
} from './constants';

interface SnsTopicProps {
  readonly env: DeploymentEnvironment;
  readonly stage: string;
}

export class SnsTopicStack extends DeploymentStack {
  public readonly monteCarloInboundTopic: Topic;
  public readonly monteCarloOutboundTopic: Topic;
  public readonly freshDeskInboundTopic: Topic;
  public readonly freshDeskOutboundTopic: Topic;
  public readonly defaultTopic: Topic;

  constructor(scope: Construct, id: string, props: SnsTopicProps) {
    super(scope, id, {
      env: props.env,
      softwareType: SoftwareType.INFRASTRUCTURE,
    });

    const monteCarloInboundTopicName = `${MONTE_CARLO_INBOUND_TOPIC}-${props.stage}`;
    this.monteCarloInboundTopic = new Topic(this, monteCarloInboundTopicName, {
      displayName: monteCarloInboundTopicName,
      topicName: monteCarloInboundTopicName,
    });

    const monteCarloOutboundTopicName = `${MONTE_CARLO_OUTBOUND_TOPIC}-${props.stage}`;
    this.monteCarloOutboundTopic = new Topic(this, monteCarloOutboundTopicName, {
      displayName: monteCarloOutboundTopicName,
      topicName: monteCarloOutboundTopicName,
    });

    const freshDeskInboundTopicName = `${FRESH_DESK_INBOUND_TOPIC}-${props.stage}`;
    this.freshDeskInboundTopic = new Topic(this, freshDeskInboundTopicName, {
      displayName: freshDeskInboundTopicName,
      topicName: freshDeskInboundTopicName,
    });

    const freshDeskOutboundTopicName = `${FRESH_DESK_OUTBOUND_TOPIC}-${props.stage}`;
    this.freshDeskOutboundTopic = new Topic(this, freshDeskOutboundTopicName, {
      displayName: freshDeskOutboundTopicName,
      topicName: freshDeskOutboundTopicName,
    });

    const defaultTopicName = `defaultTopic-${props.stage}`;
    this.defaultTopic = new Topic(this, defaultTopicName, {
      displayName: defaultTopicName,
      topicName: defaultTopicName,
    });
  }
}
