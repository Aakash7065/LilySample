import { BrazilPackage, DeploymentEnvironment, DeploymentStack, LambdaAsset, SoftwareType } from '@amzn/pipelines';
import { Duration } from 'aws-cdk-lib';
import { Construct } from 'constructs';

import { Function, Runtime } from 'aws-cdk-lib/aws-lambda';
import { Queue } from 'aws-cdk-lib/aws-sqs';
import { AttributeType, BillingMode, StreamViewType, Table, TableEncryption } from 'aws-cdk-lib/aws-dynamodb';
import {
  CompositePrincipal,
  ManagedPolicy,
  PolicyDocument,
  PolicyStatement,
  Role,
  ServicePrincipal,
} from 'aws-cdk-lib/aws-iam';
import { SqsEventSource } from 'aws-cdk-lib/aws-lambda-event-sources';
import { CfnPipe } from 'aws-cdk-lib/aws-pipes';
import { Topic } from 'aws-cdk-lib/aws-sns';
import { FRESH_DESK_CLIENT_ID, MONTE_CARLO_CLIENT_ID } from './constants';

interface ServiceStackProps {
  readonly env: DeploymentEnvironment;
  readonly stage: string;
  readonly monteCarloInboundQueue: Queue;
  readonly freshDeskInBoundQueue: Queue;
  readonly defaultTopic: Topic;
  readonly monteCarloOutboundTopic: Topic;
  readonly freshDeskOutboundTopic: Topic;
}

export class ServiceStack extends DeploymentStack {
  public readonly metaDataDb: Table;
  public readonly metaDataProcessingLambdaRole: Role;
  public readonly metaDataProcessingLambda;
  public readonly pipeRole: Role;

  constructor(scope: Construct, id: string, props: ServiceStackProps) {
    super(scope, id, {
      env: props.env,
      softwareType: SoftwareType.INFRASTRUCTURE,
    });
    const metaDataDbName = `metadata-db-${props.stage}`;

    this.metaDataDb = new Table(this, metaDataDbName, {
      tableName: metaDataDbName,
      partitionKey: {
        name: 'tableId',
        type: AttributeType.STRING,
      },
      sortKey: {
        name: 'clientId',
        type: AttributeType.STRING,
      },
      billingMode: BillingMode.PAY_PER_REQUEST,
      encryption: TableEncryption.AWS_MANAGED,
      stream: StreamViewType.NEW_IMAGE,
    });

    const metaDataProcessingLambdaRoleName = `metadata-processing-lambda-role-${props.stage}`;

    this.metaDataProcessingLambdaRole = new Role(this, metaDataProcessingLambdaRoleName, {
      roleName: metaDataProcessingLambdaRoleName,
      assumedBy: new CompositePrincipal(new ServicePrincipal('lambda.amazonaws.com')),
      managedPolicies: [
        ManagedPolicy.fromAwsManagedPolicyName('service-role/AWSLambdaBasicExecutionRole'),
        ManagedPolicy.fromAwsManagedPolicyName('Service-role/AWSLambdaVPCAccessExecutionRole'),
      ],
      inlinePolicies: {
        allAccess: new PolicyDocument({
          statements: [
            new PolicyStatement({
              actions: ['*'],
              resources: ['*'],
            }),
          ],
        }),
      },
    });
    const metaDataProcessingLambdaName = `metaDataProcessingLambda-${props.stage}`;
    this.metaDataProcessingLambda = new Function(this, metaDataProcessingLambdaName, {
      functionName: metaDataProcessingLambdaName,
      description: `Timestamp: ${new Date().toISOString()} `,
      code: LambdaAsset.fromBrazil({
        brazilPackage: BrazilPackage.fromString('LilySample-1.0'),
        componentName: 'LilySample',
      }),
      environment: {
        stage: props.stage,
        region: props.env.region,
        metadataTableName: this.metaDataDb.tableName,
      },
      handler: 'handlers.process_metadata',
      memorySize: 512,
      timeout: Duration.minutes(4),
      runtime: Runtime.PYTHON_3_9,
      role: this.metaDataProcessingLambdaRole,
    });

    this.metaDataProcessingLambda.addEventSource(
      new SqsEventSource(props.monteCarloInboundQueue, {
        batchSize: 10,
        reportBatchItemFailures: true,
      }),
    );

    this.metaDataProcessingLambda.addEventSource(
      new SqsEventSource(props.freshDeskInBoundQueue, {
        batchSize: 10,
        reportBatchItemFailures: true,
      }),
    );

    const pipeRoleName = `EventBridgePipeRole-${props.stage}`;
    this.pipeRole = new Role(this, pipeRoleName, {
      roleName: pipeRoleName,
      assumedBy: new ServicePrincipal('pipes.amazonaws.com'),
      inlinePolicies: {
        allAccess: new PolicyDocument({
          statements: [
            new PolicyStatement({
              actions: ['*'],
              resources: ['*'],
            }),
          ],
        }),
      },
    });

    if (!this.metaDataDb.tableStreamArn) {
      throw new Error('DynamoDB stream ARN is undefined. Make sure streams are enabled on the table.');
    }

    const montecarloPipeName = `monteCarloPipe-${props.stage}`;
    const monteCarloPipe = new CfnPipe(this, montecarloPipeName, {
      roleArn: this.pipeRole.roleArn,
      source: this.metaDataDb.tableStreamArn!,
      sourceParameters: {
        dynamoDbStreamParameters: {
          startingPosition: 'LATEST',
          batchSize: 10,
        },
        filterCriteria: {
          filters: [
            {
              pattern: JSON.stringify({
                dynamodb: {
                  NewImage: {
                    clientId: {
                      S: [MONTE_CARLO_CLIENT_ID],
                    },
                  },
                },
              }),
            },
          ],
        },
      },

      target: props.monteCarloOutboundTopic.topicArn,
      targetParameters: {
        inputTemplate: JSON.stringify({
          eventName: '<$.dynamodb.eventName>',
          id: '<$.dynamodb.NewImage.id.S>',
          clientId: '<$.dynamodb.NewImage.clientId.S>',
          data: '<$.dynamodb.NewImage>',
        }),
      },
    });

    const freshdeskPipeName = `freshdeskPipe-${props.stage}`;
    const freshdeskPipe = new CfnPipe(this, freshdeskPipeName, {
      roleArn: this.pipeRole.roleArn,
      source: this.metaDataDb.tableStreamArn!,
      sourceParameters: {
        dynamoDbStreamParameters: {
          startingPosition: 'LATEST',
          batchSize: 10,
        },
        filterCriteria: {
          filters: [
            {
              pattern: JSON.stringify({
                dynamodb: {
                  NewImage: {
                    clientId: {
                      S: [FRESH_DESK_CLIENT_ID],
                    },
                  },
                },
              }),
            },
          ],
        },
      },

      target: props.freshDeskOutboundTopic.topicArn,
      targetParameters: {
        inputTemplate: JSON.stringify({
          eventName: '<$.dynamodb.eventName>',
          id: '<$.dynamodb.NewImage.id.S>',
          clientId: '<$.dynamodb.NewImage.clientId.S>',
          data: '<$.dynamodb.NewImage>',
        }),
      },
    });
  }
}
