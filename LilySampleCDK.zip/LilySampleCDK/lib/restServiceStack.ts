import { BrazilPackage, DeploymentEnvironment, DeploymentStack, LambdaAsset, SoftwareType } from '@amzn/pipelines';
import { Function, Runtime } from 'aws-cdk-lib/aws-lambda';
import {
  CompositePrincipal,
  ManagedPolicy,
  PolicyDocument,
  PolicyStatement,
  Role,
  ServicePrincipal,
} from 'aws-cdk-lib/aws-iam';
import { EndpointType, LambdaIntegration, LogGroupLogDestination, RestApi } from 'aws-cdk-lib/aws-apigateway';
import { Construct } from 'constructs';
import { Duration } from 'aws-cdk-lib';
import { LogGroup } from 'aws-cdk-lib/aws-logs';
import { Queue } from 'aws-cdk-lib/aws-sqs';

interface RestServiceStackProps {
  readonly env: DeploymentEnvironment;
  readonly stage: string;
  readonly metadataTableName: string;
  readonly monteCarloInboundQueue: Queue;
  readonly freshDeskInBoundQueue: Queue;
}

export class RestServiceStack extends DeploymentStack {
  public readonly metadataHandler;
  public readonly metadataHandlerRole: Role;
  public readonly metadataQueryService;
  public readonly metadataQueryServiceRole: Role;
  public readonly apiGateway: RestApi;

  constructor(scope: Construct, id: string, props: RestServiceStackProps) {
    super(scope, id, {
      softwareType: SoftwareType.INFRASTRUCTURE,
      ...props,
    });

    const metadataHandlerRoleName = `metadataHandlerRole-${props.stage}`;
    this.metadataHandlerRole = new Role(this, metadataHandlerRoleName, {
      roleName: metadataHandlerRoleName,
      assumedBy: new CompositePrincipal(new ServicePrincipal('lambda.amazonaws.com')),
      managedPolicies: [
        ManagedPolicy.fromAwsManagedPolicyName('service-role/AWSLambdaBasicExecutionRole'),
        ManagedPolicy.fromAwsManagedPolicyName('Service-role/AWSLambdaVPCAccessExecutionRole'),
      ],
      inlinePolicies: {
        allAccess: new PolicyDocument({
          statements: [
            new PolicyStatement({
              actions: ['*'],
              resources: ['*'],
            }),
          ],
        }),
      },
    });

    this.metadataHandler = new Function(this, 'metadataHandler', {
      functionName: `metadataHandler-${props.stage}`,
      description: `Timestamp: ${new Date().toISOString()} `,
      code: LambdaAsset.fromBrazil({
        brazilPackage: BrazilPackage.fromString('LilySample-1.0'),
        componentName: 'LilySample',
      }),
      environment: {
        stage: props.stage,
        region: props.env.region,
        metadataTableName: props.metadataTableName,
        monteCarloInboundQueue: props.monteCarloInboundQueue.queueUrl,
        freshDeskInBoundQueue: props.freshDeskInBoundQueue.queueUrl,
      },
      handler: 'handlers.metadata_handler',
      memorySize: 512,
      timeout: Duration.minutes(10),
      runtime: Runtime.PYTHON_3_9,
      role: this.metadataHandlerRole,
    });

    const metadataQueryServiceRoleName = `metadataQueryServiceRole-${props.stage}`;
    this.metadataQueryServiceRole = new Role(this, metadataQueryServiceRoleName, {
      roleName: metadataQueryServiceRoleName,
      assumedBy: new CompositePrincipal(new ServicePrincipal('lambda.amazonaws.com')),
      managedPolicies: [
        ManagedPolicy.fromAwsManagedPolicyName('service-role/AWSLambdaBasicExecutionRole'),
        ManagedPolicy.fromAwsManagedPolicyName('Service-role/AWSLambdaVPCAccessExecutionRole'),
      ],
      inlinePolicies: {
        allAccess: new PolicyDocument({
          statements: [
            new PolicyStatement({
              actions: ['*'],
              resources: ['*'],
            }),
          ],
        }),
      },
    });

    this.metadataQueryService = new Function(this, 'metadataQueryService', {
      functionName: `metadataQueryService-${props.stage}`,
      description: `Timestamp: ${new Date().toISOString()} `,
      code: LambdaAsset.fromBrazil({
        brazilPackage: BrazilPackage.fromString('LilySample-1.0'),
        componentName: 'LilySample',
      }),
      environment: {
        stage: props.stage,
        region: props.env.region,
        metadataTableName: props.metadataTableName,
      },
      handler: 'handlers.metadata_query_service',
      memorySize: 512,
      timeout: Duration.minutes(10),
      runtime: Runtime.PYTHON_3_9,
      role: this.metadataQueryServiceRole,
    });

    this.apiGateway = new RestApi(this, 'metadataApi', {
      restApiName: 'metadataApi',
      description: 'Metadata API',
      deployOptions: {
        stageName: props.stage,
        accessLogDestination: new LogGroupLogDestination(new LogGroup(this, 'metadataApiAccessLogs')),
      },
      endpointConfiguration: {
        types: [EndpointType.REGIONAL],
      },
    });

    const metadataHandlerIntegration = new LambdaIntegration(this.metadataHandler);
    const metadataQueryServiceIntegration = new LambdaIntegration(this.metadataQueryService);

    const metadataResource = this.apiGateway.root.addResource('metadata');
    metadataResource.addMethod('POST', metadataHandlerIntegration);

    const metadataQueryResource = this.apiGateway.root.addResource('query-metadata');
    metadataQueryResource.addMethod('GET', metadataQueryServiceIntegration, {
      requestParameters: {
        'method.request.querystring.tableId': true,
        'method.request.querystring.clientId': true,
      },
    });
  }
}
