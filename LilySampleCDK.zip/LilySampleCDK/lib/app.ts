#!/usr/bin/env node
import { App } from 'aws-cdk-lib';
import {
  BrazilPackage,
  DeploymentPipeline,
  GordianKnotScannerApprovalWorkflowStep,
  Platform,
  ScanProfile,
} from '@amzn/pipelines';
import { ServiceStack } from './serviceStack';
import { MonitoringStack } from './monitoringStack';
import { SnsTopicStack } from './snsTopic';
import { SqsStack } from './sqsStack';
import { RestServiceStack } from './restServiceStack';

// Set up your CDK App
const app = new App();

const applicationAccount = '597088060305';

const pipeline = new DeploymentPipeline(app, 'Pipeline', {
  account: applicationAccount,
  pipelineName: 'LilySample',
  versionSet: 'LilySample/development',
  versionSetPlatform: Platform.AL2_AARCH64,
  trackingVersionSet: 'live', // Or any other version set you prefer
  bindleGuid: 'amzn1.bindle.resource.73alzzoe35uec6hkxlyq',
  description: 'Python Lambda basic pipeline managed by CDK',
  pipelineId: '7272150',
  notificationEmailAddress: 'singhmgq@amazon.com',
  selfMutate: true,
});

['LilySample', 'LilySampleTests'].forEach((pkg) => pipeline.addPackageToAutobuild(BrazilPackage.fromString(pkg)));

pipeline.versionSetStage.addApprovalWorkflow('VersionSet Workflow').addStep(
  new GordianKnotScannerApprovalWorkflowStep({
    platform: Platform.AL2_X86_64, // https://issues.amazon.com/issues/GK-956
    scanProfileName: ScanProfile.ASSERT_LOW,
  }),
);

const stageName = 'alpha';
const alphaStage = pipeline.addStage(stageName, { isProd: false });
const deploymentGroup = alphaStage.addDeploymentGroup({
  name: 'alphaApplication',
});

const env = pipeline.deploymentEnvironmentFor('597088060305', 'us-west-2');
const snsTopicStack = new SnsTopicStack(app, `LilySample-SnsTopic-${stageName}`, {
  env,
  stage: stageName,
});

const sqsStack = new SqsStack(app, `LilySample-Sqs-${stageName}`, {
  env,
  stage: stageName,
  monteCarloInboundTopic: snsTopicStack.monteCarloInboundTopic,
  freshDeskInboundTopic: snsTopicStack.freshDeskInboundTopic,
});

const serviceStack = new ServiceStack(app, `LilySample-Service-${stageName}`, {
  env,
  stage: alphaStage.name,
  monteCarloInboundQueue: sqsStack.monteCarloInboundQueue,
  freshDeskInBoundQueue: sqsStack.freshDeskInboundQueue,
  defaultTopic: snsTopicStack.defaultTopic,
  monteCarloOutboundTopic: snsTopicStack.monteCarloOutboundTopic,
  freshDeskOutboundTopic: snsTopicStack.freshDeskOutboundTopic,
});
const restServiceStack = new RestServiceStack(app, `LilySample-RestService-${stageName}`, {
  env,
  stage: stageName,
  metadataTableName: serviceStack.metaDataDb.tableName,
  monteCarloInboundQueue: sqsStack.monteCarloInboundQueue,
  freshDeskInBoundQueue: sqsStack.freshDeskInboundQueue,
});
deploymentGroup.addStacks(snsTopicStack, sqsStack, serviceStack, restServiceStack);
