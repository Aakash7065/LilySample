def test_lily_sample_importable():
    import lily_sample  # noqa: F401
