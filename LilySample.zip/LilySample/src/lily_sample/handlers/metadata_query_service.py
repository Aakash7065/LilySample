import json
import logging
from typing import Dict, Any

from lily_sample.clients.dynamo_client import DynamoDBMetadataRepository
from lily_sample.helpers.common_helper import build_response
from lily_sample.helpers.json_helper import DecimalEncoder

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

def validate_query_parameters(query_params: Dict[str, Any]) -> Dict[str, str]:
    """
    Validates and extracts required query parameters.

    :param query_params: Query parameters from the event.
    :return: A dictionary containing validated `tableId` and `clientId`.
    :raises ValueError: If required parameters are missing.
    """
    table_id = query_params.get('tableId')
    client_id = query_params.get('clientId')

    if not table_id or not client_id:
        raise ValueError("Both 'tableId' and 'clientId' must be provided as query parameters")

    return {"tableId": table_id, "clientId": client_id}

def metadata_query_service(event, context):
    logger.info("event: ", event)
    query_params = validate_query_parameters(event.get('queryStringParameters', {}))
    # Retrieve metadata from DynamoDB
    dynamo_client = DynamoDBMetadataRepository()
    item = dynamo_client.get_metadata(query_params['tableId'], query_params['clientId'])

    # Return success response
    return build_response(200, item.to_dict(), encoder=DecimalEncoder)
