import json
import logging
from typing import Dict, List

from aws_lambda_powertools.utilities.parser import parse

from lily_sample.clients.sqs_client import send_to_sqs
from lily_sample.constants import constants
from lily_sample.helpers.common_helper import build_response
from lily_sample.helpers.queue_helper import get_queue_url
from lily_sample.models.batch_metadata_request import BatchMetadataRequest

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

def batch_messages(messages: List[Dict], batch_size: int) -> List[List[Dict]]:
    """
    Splits messages into batches of a given size.

    :param messages: List of messages to batch.
    :param batch_size: Maximum batch size.
    :return: A list containing message batches.
    """
    return [messages[i:i + batch_size] for i in range(0, len(messages), batch_size)]

def process_messages_by_client(request_data: BatchMetadataRequest) -> Dict[str, List[Dict]]:
    """
    Groups messages by client ID.

    :param request_data: Parsed request containing metadata items.
    :return: A dictionary mapping client IDs to lists of messages.
    """
    client_messages: Dict[str, List[Dict]] = {}
    for item in request_data.items:
        client_messages.setdefault(item.clientId, []).append(item.dict())
    return client_messages

def send_messages_to_queues(client_messages: Dict[str, List[Dict]]):
    """
    Sends batched messages to their respective client SQS queues.

    :param client_messages: Dictionary of client IDs and their respective messages.
    """
    for client_id, messages in client_messages.items():
        try:
            queue_url = get_queue_url(client_id)
            logger.info(f"Resolved queue URL for client '{client_id}': {queue_url}")

            # Process and send messages in batches
            for batch in batch_messages(messages, constants.BATCH_SIZE):
                logger.info(f"Sending batch of size {len(batch)} to queue {queue_url}")
                send_to_sqs(batch, queue_url)

        except ValueError as e:
            logger.error(f"Error processing client '{client_id}': {e}")
            raise

def metadata_handler(event, context):
    """
    AWS Lambda function handler for processing metadata.

    :param event: AWS Lambda event object.
    :param context: AWS Lambda context object.
    :return: API Gateway response.
    """
    try:
        logger.info("Received event: %s", event)
        request_data = parse(event=event.get('body'), model=BatchMetadataRequest)

        client_messages = process_messages_by_client(request_data)
        send_messages_to_queues(client_messages)

        return build_response(200, {"Success": "All messages processed successfully"})

    except ValueError as ve:
        logger.error(f"Validation error: {ve}")
        return build_response(400, {"error": str(ve)})

    except Exception as e:
        logger.exception("An unexpected error occurred")
        return build_response(500, {"error": "Internal server error"})
