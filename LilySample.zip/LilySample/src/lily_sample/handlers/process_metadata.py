import logging
from typing import List, Dict, Any

from aws_lambda_powertools.utilities.data_classes import SQSEvent
from lily_sample.processor.metadata_processor import MetadataProcessor

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

def build_batch_response(failed_message_ids: List[str]) -> Dict[str, Any]:
    """
    Builds the batch response for failed messages.

    :param failed_message_ids: List of failed message IDs.
    :return: Response with failed item identifiers.
    """
    logger.info(f"Failed message IDs: {failed_message_ids}")
    return {
        "batchItemFailures": [
            {"itemIdentifier": message_id} for message_id in failed_message_ids
        ]
    }

def process_metadata(event, context):
    logger.info("Received event", event)
    sqs_event = SQSEvent(event)
    records = [record.raw_event for record in sqs_event.records]
    try:
        processor = MetadataProcessor()
        failed_message_ids = processor.process_batch(records)
        return build_batch_response(failed_message_ids)
    except Exception as e:
        logger.error(f"Fatal error processing batch: {e}")
        return build_batch_response([record['messageId'] for record in records])
