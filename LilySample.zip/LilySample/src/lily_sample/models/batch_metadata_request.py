from typing import Dict, Any, List

from aws_lambda_powertools.utilities.parser import BaseModel
from pydantic import Field

MAX_BATCH_SIZE = 100


class Metadata(BaseModel):
    source: str
    timestamp: str
    data: Dict[str, Any]

class MetadataItem(BaseModel):
    tableId: str = Field(min_length=1)
    clientId: str = Field(min_length=1)
    metadata: Metadata

class BatchMetadataRequest(BaseModel):
    items: List[MetadataItem] = Field(max_items=MAX_BATCH_SIZE)