from dataclasses import dataclass
from typing import Dict


@dataclass
class MetadataDbItem:
    tableId: str
    clientId: str
    metadata: Dict
    source: str
    timestamp: str

    def to_dict(self):
        return {
            'tableId': self.tableId,
            'clientId': self.clientId,
            'metadata': self.metadata,
            'source': self.source,
            'timestamp': self.timestamp
        }
