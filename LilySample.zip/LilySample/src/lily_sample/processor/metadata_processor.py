import json
import logging
from typing import Dict, Optional, List

from lily_sample.clients.dynamo_client import DynamoDBMetadataRepository
from aws_lambda_powertools.utilities.validation import validate
from aws_lambda_powertools.utilities.validation.exceptions import SchemaValidationError
from lily_sample.constants import constants
from lily_sample.helpers.json_helper import DecimalJsonDecoder
from lily_sample.models.metadata_db_item import MetadataDbItem

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


def validate_and_transform_message(record: Dict) -> Optional[MetadataDbItem]:
    """Validate and transform the SQS message."""
    try:
        message = json.loads(record.get('body', '{}'), cls=DecimalJsonDecoder)
        logger.info(f"Processing message: {message}")
        validate(event=message, schema=constants.METADATA_SCHEMA)
        logger.info(f"Message validated successfully: {message}")
        return MetadataDbItem(
            tableId=message['tableId'],
            clientId=message['clientId'],
            metadata=message['metadata'],
            source=message['metadata']['source'],
            timestamp=message['metadata']['timestamp']
        )
    except SchemaValidationError as e:
        logger.error(f"Schema validation failed: {e}")
        return None
    except json.JSONDecodeError as e:
        logger.error(f"Invalid JSON format: {e}")
        return None
    except Exception as e:
        logger.error(f"Unexpected error processing message: {e}")
        return None


class MetadataProcessor:
    def __init__(self):
        self.repository = DynamoDBMetadataRepository()

    def process_record(self, record: Dict) -> bool:
        """Process individual record and return success/failure."""
        try:
            logger.info(f"processing record: {record}")
            metadata_item = validate_and_transform_message(record)
            if metadata_item is None:
                return False

            return self.repository.write_metadata(metadata_item)

        except Exception as e:
            logger.error(f"Failed to process record: {e}")
            return False

    def process_batch(self, records: List[Dict]) -> List[str]:
        """
        Process batch of records and return list of failed message IDs.
        """
        failed_message_ids = []
        for record in records:
            try:
                success = self.process_record(record)
                if not success:
                    failed_message_ids.append(record['messageId'])
            except Exception as e:
                logger.error(f"Error processing record {record['messageId']}: {e}")
                failed_message_ids.append(record['messageId'])

        return failed_message_ids
