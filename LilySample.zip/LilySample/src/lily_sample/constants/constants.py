REGION = 'us-west-2'
METADATA_SCHEMA = {
    "type": "object",
    "properties": {
        "tableId": {"type": "string", "minLength": 1},
        "clientId": {"type": "string", "minLength": 1},
        "metadata": {
            "type": "object",
            "properties": {
                "source": {"type": "string"},
                "timestamp": {"type": "string"},
                "data": {"type": "object"}
            },
            "required": ["source", "timestamp", "data"]
        }
    },
    "required": ["tableId", "clientId", "metadata"]
}
METADATA_TABLE_KEY = 'metadataTableName'
MONTECARLO_QUEUE_URL_KEY = 'monteCarloInboundQueue'
FRESHDESK_QUEUE_URL_KEY = 'freshDeskInBoundQueue'
MONTECARLO_CLIENT_ID = 'montecarlo'
FRESHDESK_CLIENT_ID = 'freshdesk'
BATCH_SIZE = 10