import json
from typing import Dict, Any


def build_response(status_code: int, body: Any, encoder: Any = None) -> Dict[str, Any]:
    """
    Builds an API Gateway-compatible HTTP response.

    :param status_code: HTTP status code for the response.
    :param body: Response body.
    :param encoder: Custom JSON encoder for special data types.
    :return: Formatted response dictionary.
    """
    return {
        "isBase64Encoded": False,
        "statusCode": status_code,
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps(body, cls=encoder) if encoder else json.dumps(body),
    }