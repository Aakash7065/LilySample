
from decimal import Decimal
import json
from typing import Any



class DecimalJsonDecoder(json.JSONDecoder):
    """Custom JSON decoder to automatically convert floats to Decimal."""

    def __init__(self, *args, **kwargs):
        super().__init__(parse_float=Decimal, *args, **kwargs)

    def decode(self, s: str, _w=None) -> Any:
        """
        Decode JSON string with float to Decimal conversion.
        Args:
            s: JSON string to decode
            _w: Optional whitespace handling (internal use)
        Returns:
            Decoded JSON with Decimal values
        """
        result = super().decode(s)
        return self._decode_floats(result)

    def _decode_floats(self, obj: Any) -> Any:
        """
        Recursively convert float values to Decimal in nested structures.
        """
        if isinstance(obj, dict):
            return {key: self._decode_floats(value) for key, value in obj.items()}
        elif isinstance(obj, list):
            return [self._decode_floats(item) for item in obj]
        elif isinstance(obj, float):
            return Decimal(str(obj))
        return obj


class DecimalEncoder(json.JSONEncoder):
    """Custom JSON encoder to handle Decimal types."""
    def default(self, obj):
        if isinstance(obj, Decimal):
            return str(obj)
        return super(DecimalEncoder, self).default(obj)
