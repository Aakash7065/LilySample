import os

from lily_sample.constants import constants

QUEUE_URLS = {
    constants.MONTECARLO_CLIENT_ID: os.environ.get(constants.MONTECARLO_QUEUE_URL_KEY),
    constants.FRESHDESK_CLIENT_ID: os.environ.get(constants.FRESHDESK_QUEUE_URL_KEY)
}

def get_queue_url(client_id: str) -> str:
    """Get the appropriate queue URL based on client ID."""
    if client_id.lower().startswith(constants.MONTECARLO_CLIENT_ID):
        return QUEUE_URLS[constants.MONTECARLO_CLIENT_ID]
    elif client_id.lower().startswith(constants.FRESHDESK_CLIENT_ID):
        return QUEUE_URLS[constants.FRESHDESK_CLIENT_ID]
    else:
        raise ValueError(f"Unknown client ID format: {client_id}")