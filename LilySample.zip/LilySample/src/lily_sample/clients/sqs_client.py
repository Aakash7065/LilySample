import json
import logging
from typing import List, Dict
from botocore.exceptions import ClientError

from lily_sample.clients.clients import get_sqs_client
from lily_sample.constants import constants

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

sqs_client = get_sqs_client(constants.REGION)


def send_to_sqs(messages: List[Dict], queue_url: str) -> bool:
    """Send batch messages to SQS queue."""
    try:
        response = sqs_client.send_message_batch(
            QueueUrl=queue_url,
            Entries=[
                {
                    'Id': str(idx),
                    'MessageBody': json.dumps(msg)
                }
                for idx, msg in enumerate(messages)
            ]
        )

        if 'Failed' in response and response['Failed']:
            logger.error(f"Some messages failed to send: {response['Failed']}")
            return False

        return True

    except ClientError as e:
        logger.error(f"Failed to send messages to SQS: {e}")
        raise
