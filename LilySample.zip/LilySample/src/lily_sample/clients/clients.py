import boto3


def get_dynamo_client(region):
    return boto3.resource('dynamodb', region_name=region)

def get_sqs_client(region):
    return boto3.client('sqs', region_name=region)