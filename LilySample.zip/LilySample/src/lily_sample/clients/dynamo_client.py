import logging
import os
from typing import Optional

from botocore.exceptions import ClientError

from lily_sample.clients.clients import get_dynamo_client
from lily_sample.constants import constants
from lily_sample.models.metadata_db_item import MetadataDbItem

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

class DynamoDBMetadataRepository:
    """Repository class for DynamoDB operations."""

    def __init__(self):
        self.dynamodb = get_dynamo_client(constants.REGION)
        self.table = self.dynamodb.Table(os.getenv(constants.METADATA_TABLE_KEY))

    def write_metadata(self, metadata_item: MetadataDbItem) -> bool:
        """
        Write metadata item to DynamoDB.
        Returns True if successful, False otherwise.
        """
        try:
            item = {
                'tableId': metadata_item.tableId,
                'clientId': metadata_item.clientId,
                'metadata': metadata_item.metadata,
                'source': metadata_item.source,
                'timestamp': metadata_item.timestamp
            }

            self.table.put_item(Item=item)
            logger.info(f"Successfully wrote item to DynamoDB: {metadata_item.tableId}-{metadata_item.clientId}")
            return True

        except ClientError as e:
            logger.error(f"Failed to write to DynamoDB: {e}")
            return False

    def get_metadata(self, table_id: str, client_id: str) -> Optional[MetadataDbItem]:
        """
        Retrieve metadata item from DynamoDB using composite key.

        Args:
            table_id (str): Partition key (tableId)
            client_id (str): Sort key (clientId)

        Returns:
            Optional[MetadataDbItem]: Retrieved item as MetadataDbItem if found, None otherwise
        """
        try:
            response = self.table.get_item(
                Key={
                    'tableId': table_id,
                    'clientId': client_id
                }
            )

            # Check if item exists
            if 'Item' not in response:
                logger.info(f"No item found for tableId={table_id}, clientId={client_id}")
                return None

            item = response['Item']

            # Convert DynamoDB item to MetadataDbItem
            return MetadataDbItem(
                tableId=item['tableId'],
                clientId=item['clientId'],
                metadata=item['metadata'],
                source=item['source'],
                timestamp=item['timestamp']
            )

        except ClientError as e:
            error_code = e.response['Error']['Code']
            error_message = e.response['Error']['Message']
            logger.error(f"Failed to get item from DynamoDB: {error_code} - {error_message}")
            return None
        except KeyError as e:
            logger.error(f"Missing required attribute in DynamoDB item: {e}")
            return None
        except Exception as e:
            logger.error(f"Unexpected error retrieving item from DynamoDB: {e}")
            return None

